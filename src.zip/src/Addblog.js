import axios from "axios";
import { useState } from "react";
import Navbar from "./navbar";
function Addblog(){
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [url, setUrl] = useState('');

    let add = () => {
        axios.post("http://127.0.0.1:3000/blogs", {
            blog_tilte: title,
            blog_descp: description,
            users_id: 1
        })
    }
    return (
        <>
            <Navbar/>
            <h1 className="text-center heading">Create a Blog</h1>
            <div className="moviedetail container">
                    <div className="card mb-3 addBlog">
                        <div className="blog-title">
                        <label>Title</label>
                        <br></br>
                        <input onChange={(e) => setTitle(e.target.value)} type="text" placeholder="Enter your blog title" className="blog-input"/>
                        </div>
                        <div className="blog-descp">
                        <label>Description</label>
                        <br></br>
                        <textarea onChange={(e) => setDescription(e.target.value)} className="desc-text blog-input" id="desc"></textarea>
                        </div>
                        <button type="button" class="btn btn-outline-success m-2">Upload Image</button>
                        <button type="button" onClick={() => add()} class="btn btn-outline-success m-2">Add Blog</button>
                    </div>
                </div>
        </>
    );
}
export default Addblog