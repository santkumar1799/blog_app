import Navbar from "./navbar";
import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
function Blogdetail() {
    const params = useParams()
    const [blog, setBlog] = useState();
    const [errorMessage, setErrorMessage] = useState("");
    const [id, setId] = useState(params.id);
    useEffect(() => {
        const getBlog = async () => {
            const response = await fetch(`http://127.0.0.1:3000/blogs/${id}`);
            const result = await response.json();
            console.log(result);
            if (response.ok) {
                setBlog(result);
            } else {
                setErrorMessage(result.message);
            }
        }
        getBlog();
    }, [])

    return (
        <>
            <Navbar />
            {blog &&
                <div className="moviedetail container">
                    <div className="card mb-3">
                        <img className="card-img-top" src="https://bit.ly/3AxKOmH" alt="Card image cap" />
                        <div className="card-body">
                            <h5 className="card-title">Title :&nbsp;{blog.id}</h5>
                            <h5 className="card-title">Genre :&nbsp;{blog.blog_title}</h5>
                            <h5 className="card-title">Year : &nbsp;{blog.blog_descp}</h5>
                            <p className="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        </div>
                    </div>
                </div>
            }
        </>
    )
}
export default Blogdetail;