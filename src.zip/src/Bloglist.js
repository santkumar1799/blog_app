import { Link } from "react-router-dom";
function Bloglist({ blogs}) {
    return (
        <>
            <div className="container movies">
                <div className=" movie row">
                    {blogs && blogs.map((blog, index) => (
                        <div className='movieimg'>
                            <img className="img" src="https://bit.ly/3AxKOmH" alt='movie' />
                                <h5 className="card-title">Title :&nbsp;{blog.id}</h5>
                                <h5 className="card-title">Genre :&nbsp;{blog.blog_descp}</h5>
                                <button className="btn btn-outline-success mb-4"  >
                                <Link to={`/Blogdetail/${blog.id}`}> Read More </Link>
                                </button>
                        </div>

                    ))}
                </div>
            </div>
        </>
    );
}
export default Bloglist;